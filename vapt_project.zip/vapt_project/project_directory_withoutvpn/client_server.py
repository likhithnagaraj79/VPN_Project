from flask import Flask, request, render_template
import os

app = Flask(__name__)

UPLOAD_FOLDER = 'uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    try:
        file = request.files['file']
        if not file:
            return "No file selected", 400

        file.save(os.path.join(UPLOAD_FOLDER, file.filename))
        return "File received successfully"
    except Exception as e:
        return f"Error receiving file: {e}", 500

if __name__ == "__main__":
    app.run(port=5000, debug=True)
